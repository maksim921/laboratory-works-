from tkinter import *
from lab12_2 import IceCreamStand
root = Tk()
root.title("Ice Cream Stand")
root.geometry("250x200")

label = Label(text="Available flowers")
label.pack()
widget = Listbox(width=15, height=8)
widget.pack()



restBaskin = IceCreamStand("Баскин Роббинс",  ["Фисташковое", "Крем-брюле", "Пломбир"], 4.9)

for i in restBaskin.get_flavors():
    widget.insert(0,i)
root.mainloop()