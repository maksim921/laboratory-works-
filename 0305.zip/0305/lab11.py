
# 1,3 часть
class Restaurant:
    def __init__(self,restaurant_name, cuisine_type, rating=5.0):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
        self.rating = rating

    def describe_restaurant(self):
        print(f"Название ресторана: {self.restaurant_name}, тип кухни: {self.cuisine_type}")

    def open_restaurant(self):
        print("Ресторан открыт")

    def set_rating(self, new_rating):
        self.rating = float(new_rating)


if __name__ =="__main__":
    # 1 часть
    newRestaurant = Restaurant("Суши-мастер", "Японская кухня")
    print(newRestaurant.restaurant_name)
    print(newRestaurant.cuisine_type)
    newRestaurant.describe_restaurant()
    newRestaurant.open_restaurant()

    # 2 часть
    restOsaca = Restaurant("Осака", "Японская кухня")
    restCucumber = Restaurant("Кукумбер", "Европейская, паназиатская кухня")
    restChito = Restaurant("Чито Гврито", "Грузинская кухня")

    restOsaca.describe_restaurant()
    restCucumber.describe_restaurant()
    restChito.describe_restaurant()


# 1
# class Restaurant:
#     def __init__(self,restaurant_name, cuisine_type):
#         self.restaurant_name = restaurant_name
#         self.cuisine_type = cuisine_type
#
#     def describe_restaurant(self):
#         print(f"Название ресторана: {self.restaurant_name}, тип кухни: {self.cuisine_type}")
#
#     def open_restaurant(self):
#         print("Ресторан открыт")
