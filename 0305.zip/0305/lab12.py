from lab11 import Restaurant

class IceCreamStand(Restaurant):
    def __init__(self, restaurant_name, flavors: list, rating=5.0):
        super().__init__(restaurant_name, cuisine_type="Кафе-мороженное", rating=rating)
        self.flavors = flavors

    def get_flavors(self):
        return self.flavors


if __name__ == "__main__":
    restBaskin = IceCreamStand("Баскин Роббинс",  ["Фисташковое","Крем-брюле"], 4.9)

    print(restBaskin.get_flavors())