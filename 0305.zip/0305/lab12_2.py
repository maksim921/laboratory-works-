from lab11 import Restaurant


class IceCreamStand(Restaurant):
    def __init__(self, restaurant_name, flavors: list, rating=5.0, location='', work_hours='', cream_types=None):
        super().__init__(restaurant_name, cuisine_type="Кафе-мороженное", rating=rating)
        self.flavors = flavors
        self.location = location
        self.work_hours = work_hours
        self.cream_types = cream_types

    def get_flavors(self):
        return self.flavors

    def add_flavors(self, new_flavors):
        if type(new_flavors) == list:
            self.flavors.extend(new_flavors)
        else:
            self.flavors.append(new_flavors)

    def del_flavors(self, extra_flavors):
        if type(extra_flavors) != list:
            extra_flavors = [extra_flavors]
        for i in extra_flavors:
            if i in self.flavors:
                self.flavors.remove(i)

    def check_flavor(self, fl):
        if fl in self.flavors:
            return True
        else:
            return False

    def get_cream_types(self):
        return self.cream_types

    def set_cream_types(self, new_types):
        self.cream_types = new_types


if __name__ == "__main__":
    restBaskin = IceCreamStand("Баскин Роббинс",  ["Фисташковое", "Крем-брюле"], 4.9)
    print(restBaskin.get_flavors())
    restBaskin.del_flavors("Фисташковое")
    print(restBaskin.get_flavors())

